package com.treatment;

import org.springframework.data.jpa.repository.JpaRepository;


public interface TreatmentManagementRepository extends JpaRepository<TreatmentModel, Integer> {

}
